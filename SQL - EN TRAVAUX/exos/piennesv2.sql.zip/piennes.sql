-- Création des tables

CREATE TABLE IF NOT EXISTS pays (
    code_pays varchar(2) NOT NULL PRIMARY KEY,
    nom_pays varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS villes (
    code_commune_insee varchar(15) NOT NULL PRIMARY KEY,
    code_postal varchar(15) NOT NULL,
    nom_ville varchar(80) NOT NULL,
    pays_code_pays varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS passions (
    id_passion int UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nom_passion varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS langage (
    id_langage tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nom_langage varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS NotesFinales (
    stagiaires_identifiant_stagiaire int NOT NULL,
    langage_id_langage int NOT NULL,
    note decimal(4,2) NULL,
    PRIMARY KEY (stagiaires_identifiant_stagiaire, langage_id_langage)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS aime (
    passions_id_passion int NOT NULL,
    stagiaires_identifiant_stagiaire int NOT NULL,
    PRIMARY KEY (passions_id_passion,stagiaires_identifiant_stagiaire)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS stagiaires (
    identifiant_stagiaire int UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    civilite enum('M.','Mlle','Mme') NOT NULL,
    prenom varchar(50) NOT NULL,
    nom varchar(50) NOT NULL,
    adresse varchar(250) NOT NULL,
    adresse_complement varchar(250) NOT NULL,
    email varchar(100) NULL,
    tel varchar(40) NULL,
    date_naissance date NOT NULL,
    abonnement_newsletter tinyint(1) NOT NULL,
    heure_repas_pref time NOT NULL,
    commentaire blob NOT NULL,
    villes_code_commune_insee varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- insertion des données

INSERT langage VALUES 
    (1, 'PHP'),
    (2, 'HTML'),
    (3, 'JS'),
    (4, 'PYTHON');

INSERT pays VALUES 
    ('FR', 'France'),
    ('ES', 'Espagne'),
    ('IT', 'Italie'),
    ('LU', 'Luxembourg');
    
INSERT passions VALUES 
    (NULL, 'Lire'),
    (NULL, 'Cuisine'),
    (NULL, 'Cinéma'),
    (NULL, 'L''art'),
    (NULL, 'Musique');
        
INSERT INTO villes VALUES
	('05061', '05000', 'Gap', 'FR'),
	('75101', '75001', 'Paris 01er Arrondissement', 'FR');
    
INSERT INTO NotesFinales VALUES
(1, 1, 15.3),
(1, 2, 16.95),
(1, 3, 10),
(2, 1, 9.99),
(2, 2, 8),
(2, 3, NULL),
(3, 1, 12.22),
(3, 2, 14.95),
(3, 3, 9.99),
(4, 1, NULL),
(4, 2, 10),
(4, 3, 0);

INSERT INTO aime VALUES
(1, 1),
(2, 1),
(3, 1),
(1, 2),
(4, 2),
(1, 3),
(3, 3);

INSERT INTO stagiaires VALUES
	(1, 'M.', 'Ludovic', 'GIAMBIASI', 'adresse postale', 'adresse postale complément', 'ludovic.giambiasi@gmail.com', NULL, '1980-08-10', 1, '12:30:00', 'Un long commentaire c''est génial, comment protéger les caractères ?', '05061'),
	(2, 'M.', 'Franck', 'DUPONT', 'adresse postale', 'adresse postale complément', NULL, '06 09 09 09 09', '1995-02-10', 1, '12:30:00', 'Un long commentaire c''est génial, comment protéger les caractères ?', '75101'),
	(3, 'Mlle', 'Marine', 'DU-SQL', 'adresse postale', 'adresse postale complément', 'coucou@gmail.com', '06 09 09 09 88', '1988-10-10', 0, '12:30:00', 'Un long commentaire c''est génial, comment protéger les caractères ?', '05061'),
	(4, 'Mme', 'Jacqueline', 'PARISSO', 'adresse postale', 'adresse postale complément', 'moi@gmail.com', NULL, '1960-11-10', 0, '12:30:00', 'Un long commentaire c''est génial, comment protéger les caractères ?', '05061');    

